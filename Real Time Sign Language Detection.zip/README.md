# Real-Time Sign Language Detection

A computer vision project that uses a webcam to recognize predefined hand signs in real time. The system captures live video, detects the user's hand, processes the hand region, and uses a trained machine-learning model to identify the corresponding sign.

## Overview

**Real-Time Sign Language Detection** is designed to demonstrate how computer vision and machine learning can be combined to recognize hand gestures through a webcam.

The model used in this project was trained using **Google Teachable Machine** with a custom dataset collected for the project. Once trained, the exported Keras model is integrated into the Python application for real-time prediction.

## Features

- Real-time hand/sign detection using a webcam
- Custom dataset collected for the project
- Machine-learning model trained with Google Teachable Machine
- Real-time prediction using a Keras model
- Hand detection and image processing with OpenCV/cvzone
- On-screen prediction display
- Separate data-collection workflow
- Completed working project

## Technologies Used

| Technology               | Purpose                                                     |
| ------------------------ | ----------------------------------------------------------- |
| Python                   | Core programming language                                   |
| OpenCV                   | Webcam access and image processing                          |
| cvzone                   | Simplified computer-vision utilities and hand detection     |
| MediaPipe                | Hand landmark/detection support through the vision pipeline |
| NumPy                    | Numerical and image-array processing                        |
| TensorFlow / Keras       | Loading and running the trained model                       |
| Google Teachable Machine | Training and exporting the classification model             |

## How It Works

```text
Webcam
   ↓
Capture Live Video
   ↓
Hand Detection
   ↓
Crop / Process Hand Region
   ↓
Resize & Normalize Image
   ↓
Trained Keras Model
   ↓
Sign Prediction
   ↓
Display Result on Screen
```

## Dataset

The dataset was **personally collected** for this project.

Images of hand signs were captured using the project's data-collection process and organized into classes. These images were then used with **Google Teachable Machine** to train the image-classification model.

### Dataset workflow

1. Start the data-collection script.
2. Capture images for each required sign.
3. Organize the collected images into their respective classes.
4. Upload the dataset to Google Teachable Machine.
5. Train the image-classification model.
6. Export the trained model in Keras format.
7. Place the exported model files in the project.
8. Run the real-time detection application.

## Model Training

The machine-learning model was trained using **Google Teachable Machine**.

The training process was:

```text
Custom Hand-Sign Dataset
        ↓
Google Teachable Machine
        ↓
Image Classification Training
        ↓
Trained Model
        ↓
Keras / TensorFlow Export
        ↓
Python Application
        ↓
Real-Time Prediction
```

> **Note:** Keep the model and label files required by the application in the locations expected by the Python scripts. If you move them, update the corresponding paths in the code.

## Requirements

### Software

- Python 3.x
- Webcam
- Google Teachable Machine account/browser access for model training
- Git (optional, for GitHub)

### Python Libraries

Install the required libraries with:

```bash
pip install opencv-python
pip install numpy
pip install cvzone
pip install mediapipe
pip install tensorflow
```

Or install them together:

```bash
pip install opencv-python numpy cvzone mediapipe tensorflow
```

> If your Python/TensorFlow version has compatibility issues with a particular MediaPipe or TensorFlow release, use compatible versions for your Python environment.

## Installation

### 1. Clone the repository

After creating your GitHub repository, clone it using:

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd Real-Time-Sign-Language-Detection
```

### 2. Create a virtual environment

Recommended:

```bash
python -m venv venv
```

Activate it on Windows:

```bash
venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install opencv-python numpy cvzone mediapipe tensorflow
```

### 4. Check the project files

Make sure the trained model and other required project files are present in the expected locations.

## Running the Project

After installing the dependencies, run the main real-time detection Python script from the project directory.

For example:

```bash
python test.py
```

If your main detection script has a different filename, run that script instead.

### Using the application

1. Connect a webcam to your computer.
2. Start the detection script.
3. Allow camera access if prompted.
4. Show one of the trained hand signs in front of the camera.
5. The system detects the hand and sends the processed image to the trained model.
6. The predicted sign is displayed in real time.
7. Press the key configured in the application to close the webcam window.

## Data Collection

If you want to collect additional training images, use the project's data-collection script.

For example:

```bash
python datacollection.py
```

Follow the instructions in the script to capture images for the required classes.

You can then retrain the model using Google Teachable Machine and replace the existing exported model files with the new model.

## Important Notes

- A working webcam is required for real-time detection.
- Good lighting can improve hand-detection and classification performance.
- The model can only recognize the sign classes it was trained on.
- Prediction accuracy depends on the quality, variety, and quantity of training images.
- For better generalization, collect images with different backgrounds, hand positions, distances, lighting conditions, and users.

## Limitations

- The system recognizes only the gestures included in the trained dataset.
- It is primarily a real-time gesture classification demonstration rather than a complete sign-language translation system.
- Accuracy may decrease in poor lighting or when the hand is partially hidden.
- A webcam and suitable Python environment are required.

## Future Enhancements

Some possible improvements include:

- Add more sign-language gestures and alphabets
- Support continuous sentence-level sign recognition
- Add text-to-speech output
- Improve model accuracy with a larger and more diverse dataset
- Support multiple hand gestures
- Build a web or mobile application
- Add multilingual speech/text output
- Deploy the model as an accessible real-time application

## Learning Outcomes

Through this project, I gained practical experience in:

- Python programming
- Computer vision
- Real-time webcam processing
- Hand detection
- Image classification
- Dataset collection
- Machine-learning model training
- Google Teachable Machine
- TensorFlow/Keras model integration
- Building a complete computer-vision application

## Project Status

**Completed**

This project was developed as a practical implementation of real-time hand-sign recognition using computer vision and machine learning.

## Author

**Deepak D**

---

If you found this project useful or interesting, feel free to explore the code and experiment with additional sign classes.
